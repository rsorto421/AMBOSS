# AMBOSS Anki Add-on
#
# Copyright (C) 2019-2020 AMBOSS MD Inc. <https://www.amboss.com/us>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version, with the additions
# listed at the end of the license file that accompanied this program.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

# Install pytesseract if needed
# !pip install pytesseract

import pytesseract
from PIL import Image
from bs4 import BeautifulSoup
from pathlib import Path
from typing import List, Dict

# Assuming api.py defines methods to interact with Anki collections and cards
from anki.collection import Collection

# Simplified; actual import might differ


class AnkiOCR:
    def __init__(self, collection_path: Path):
        self.collection = Collection(collection_path)

    def get_image_paths_from_card(self, card_id) -> List[Path]:
        """Extract image file paths from a given Anki card ID."""
        card = self.collection.get_card(card_id)  # Simplified; adjust based on actual api.py methods
        note = card.note()
        image_paths = []
        for field in note.fields:
            soup = BeautifulSoup(field, 'html.parser')
            for img_tag in soup.find_all('img'):
                image_src = img_tag['src']
                image_paths.append(
                    Path(self.collection.media_folder, image_src))  # Adjust based on actual media folder handling
        return image_paths

    def extract_text_from_image(self, image_path: Path) -> str:
        """Use pytesseract to extract text from a single image."""
        try:
            image = Image.open(image_path)
            return pytesseract.image_to_string(image)
        except Exception as e:
            print(f"Error processing image {image_path}: {e}")
            return ""

    def extract_texts_from_card_images(self, card_id) -> Dict[str, str]:
        """Extract texts from all images associated with a given card ID."""
        image_paths = self.get_image_paths_from_card(card_id)
        texts = {str(path): self.extract_text_from_image(path) for path in image_paths}
        return texts

# Example usage
# collection_path = Path("path/to/anki/collection")
# ank_ocr = AnkiOCR(collection_path)
# card_id = 123456789  # Example card ID
# extracted_texts = ank_ocr.extract_texts_from_card_images(card_id)
# print(extracted_texts)

